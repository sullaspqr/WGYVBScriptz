﻿Public Class Form1
    Const Regular = 2000
    Const Special = 2500
    Const Supespecial = 5000
    Const Cheese = 500
    Const Bacon = 700
    Const Pepperoni = 800

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim re As String
        Dim oPrice As Integer
        Dim aPrice As Integer
        Dim Member As Integer

        If rdbRegular.Checked = True Then
            oPrice = Regular * txtQuantity.Text
        ElseIf rdbSpecial.Checked = True Then
            oPrice = Special * txtQuantity.Text
        ElseIf rdbSuperspecial.Checked = True Then
            oPrice = Supespecial * txtQuantity.Text
        End If

        If chbBacon.Checked = True Then
            aPrice = Cheese * txtQuantity.Text
        ElseIf chbBacon.Checked = True Then
            aPrice = Bacon * txtQuantity.Text
        ElseIf chbPepperoni.Checked = True Then
            aPrice = Pepperoni * txtQuantity.Text
        End If
        If cboMembership.Text = "Igen" Then
            Member = 5%
        Else
            cboMembership.Text = "Nem"
        End If

        re = "A teljes összeg: " & " HUF " & oPrice + aPrice - Member & Environment.NewLine
        MessageBox.Show(re, " Pizza Project ", MessageBoxButtons.OK)
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Close()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        If rdbRegular.Checked = True Then
            rdbRegular.Checked = False
        ElseIf rdbSpecial.Checked = True Then
            rdbSpecial.Checked = False
        ElseIf rdbSuperspecial.Checked = True Then
            rdbSuperspecial.Checked = False
        ElseIf chbCheese.Checked = True Then
            chbCheese.Checked = False
        ElseIf chbBacon.Checked = True Then
            chbBacon.Checked = False
        ElseIf chbPepperoni.Checked = True Then
            chbPepperoni.Checked = False
        ElseIf cboMembership.Text = "Igen" Then
            cboMembership.Text = ""
        ElseIf cboMembership.Text = "Nem" Then
            cboMembership.Text = ""
        ElseIf txtQuantity.Text <> "" Then
            txtQuantity.Text = ""
        End If
    End Sub
End Class
